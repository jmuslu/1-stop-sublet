export type ListingPlatform = 'Craigslist' | 'Facebook Marketplace' | 'Zillow' | 'Airbnb' | 'SpareRoom';

export interface Listing {
  id: string;
  title: string;
  description: string;
  price: number;
  location: string;
  bedrooms: number;
  bathrooms: number;
  platform: ListingPlatform;
  dateListed: string;
  imageUrl: string;
  contactEmail?: string;
  contactPhone?: string;
}

export type SortOption = 'date-desc' | 'date-asc' | 'price-desc' | 'price-asc';
