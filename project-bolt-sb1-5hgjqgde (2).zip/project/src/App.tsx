import { useState, useMemo } from 'react';
import type { ListingPlatform, SortOption } from './types/listing';
import { mockListings } from './data/mockListings';
import Header from './components/Header';
import FilterBar from './components/FilterBar';
import ListingGrid from './components/ListingGrid';
import './App.css';

function App() {
  const [selectedPlatform, setSelectedPlatform] = useState<ListingPlatform | 'all'>('all');
  const [selectedLocation, setSelectedLocation] = useState('all');
  const [sortBy, setSortBy] = useState<SortOption>('date-desc');

  const locations = useMemo(() => {
    const uniqueLocations = new Set(mockListings.map((l) => l.location));
    return Array.from(uniqueLocations).sort();
  }, []);

  const filteredAndSortedListings = useMemo(() => {
    let result = [...mockListings];

    if (selectedPlatform !== 'all') {
      result = result.filter((listing) => listing.platform === selectedPlatform);
    }

    if (selectedLocation !== 'all') {
      result = result.filter((listing) => listing.location === selectedLocation);
    }

    result.sort((a, b) => {
      switch (sortBy) {
        case 'date-desc':
          return new Date(b.dateListed).getTime() - new Date(a.dateListed).getTime();
        case 'date-asc':
          return new Date(a.dateListed).getTime() - new Date(b.dateListed).getTime();
        case 'price-desc':
          return b.price - a.price;
        case 'price-asc':
          return a.price - b.price;
        default:
          return 0;
      }
    });

    return result;
  }, [selectedPlatform, selectedLocation, sortBy]);

  return (
    <div className="app">
      <Header />
      <main className="main-content">
        <FilterBar
          selectedPlatform={selectedPlatform}
          onPlatformChange={setSelectedPlatform}
          selectedLocation={selectedLocation}
          onLocationChange={setSelectedLocation}
          locations={locations}
          sortBy={sortBy}
          onSortChange={setSortBy}
        />
        <div className="results-count">
          {filteredAndSortedListings.length} listings found
        </div>
        <ListingGrid listings={filteredAndSortedListings} />
      </main>
      <footer className="footer">
        <p>1StopSublet - Your centralized sublet marketplace</p>
      </footer>
    </div>
  );
}

export default App;
