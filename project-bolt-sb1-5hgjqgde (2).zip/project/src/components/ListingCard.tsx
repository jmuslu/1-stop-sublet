import type { Listing } from '../types/listing';

interface ListingCardProps {
  listing: Listing;
}

function ListingCard({ listing }: ListingCardProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
    }).format(price);
  };

  return (
    <article className="listing-card">
      <div className="listing-image-container">
        <img
          src={listing.imageUrl}
          alt={listing.title}
          className="listing-image"
          loading="lazy"
        />
        <span className="listing-platform-badge">{listing.platform}</span>
      </div>
      <div className="listing-content">
        <div className="listing-header">
          <h3 className="listing-title">{listing.title}</h3>
          <span className="listing-price">{formatPrice(listing.price)}/mo</span>
        </div>
        <p className="listing-location">{listing.location}</p>
        <p className="listing-description">{listing.description}</p>
        <div className="listing-meta">
          <span className="listing-detail">
            {listing.bedrooms === 0 ? 'Studio' : `${listing.bedrooms} BR`}
            {' / '}
            {listing.bathrooms} BA
          </span>
          <span className="listing-date">Listed {formatDate(listing.dateListed)}</span>
        </div>
      </div>
    </article>
  );
}

export default ListingCard;
