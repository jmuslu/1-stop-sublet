function Header() {
  return (
    <header className="header">
      <h1 className="header-title">1StopSublet</h1>
      <p className="header-tagline">Find your perfect temporary home, all in one place</p>
    </header>
  );
}

export default Header;
